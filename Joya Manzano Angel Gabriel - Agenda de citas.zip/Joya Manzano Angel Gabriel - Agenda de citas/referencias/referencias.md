## Referencias

- [Local Storage](https://developer.mozilla.org/es/docs/Web/API/Window/localStorage)
- [Manejo de eventos On Load](https://developer.mozilla.org/es/docs/Web/API/Window/load_event)
- [Manipulación del DOM](https://developer.mozilla.org/es/docs/Web/API/Document_Object_Model)
- [Redirección con Window Location](https://developer.mozilla.org/es/docs/Web/API/Window/location)